package com.example.a_zpharmacy

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.a_zpharmacy.databinding.ActivityOilsSectionBinding
import com.example.a_zpharmacy.databinding.ActivitySectionsBinding

class Sections : AppCompatActivity() {
    private lateinit var binding: ActivitySectionsBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySectionsBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.Medicine.setOnClickListener {
            val MedicineIntent = Intent(this, Medicine_Section::class.java)
            startActivity(MedicineIntent)
        }
        binding.MakeUp.setOnClickListener {
            val MakeUpIntent = Intent(this, MakeUp_Section::class.java)
            startActivity(MakeUpIntent)
        }
    }
}