package com.example.a_zpharmacy

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import com.example.a_zpharmacy.databinding.ActivityRegisterBinding
import com.example.a_zpharmacy.databinding.ActivitySectionsBinding

class Register : AppCompatActivity() {

    private lateinit var binding: ActivityRegisterBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRegisterBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.confirmButton.setOnClickListener {

            if (binding.edFirstname.text.toString().isNotEmpty() && binding.edSecondName.text.toString().isNotEmpty() &&binding.edPass.text.toString().isNotEmpty() &&binding.edPass1.text.toString().isNotEmpty() &&binding.edPhon.text.toString().isNotEmpty()){

                // navigation to another activity
                val confirmIntent = Intent(this,Sections::class.java)
                startActivity(confirmIntent)

            }else{
                Toast.makeText(this, "Empty Firstname or empty second name or error Password or error confirm password or error phone", Toast.LENGTH_SHORT).show()
            }
        }
    }

}