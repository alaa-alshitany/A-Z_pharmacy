package com.example.a_zpharmacy

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.a_zpharmacy.databinding.ActivityFoundationSectionBinding
class FoundationSection : AppCompatActivity() {
    private lateinit var binding: ActivityFoundationSectionBinding
    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)
        binding = ActivityFoundationSectionBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.Buy2.setOnClickListener {
            val buy2Intent = Intent(this, Sections::class.java)
            startActivity(buy2Intent)
        }
    }
}