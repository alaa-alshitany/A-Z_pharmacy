package com.example.a_zpharmacy

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.a_zpharmacy.databinding.ActivityCreamsSectionBinding


class CreamsSection : AppCompatActivity() {
    private lateinit var binding: ActivityCreamsSectionBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding= ActivityCreamsSectionBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.Buy1.setOnClickListener {
                val buy1Intent = Intent(this,Sections::class.java)
                startActivity(buy1Intent)
        }
    }
}