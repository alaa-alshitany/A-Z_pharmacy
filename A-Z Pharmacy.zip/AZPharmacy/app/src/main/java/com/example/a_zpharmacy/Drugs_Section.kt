package com.example.a_zpharmacy

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.CheckBox
import android.widget.RadioButton
import android.widget.Toast
import com.example.a_zpharmacy.databinding.ActivityDrugsSectionBinding
import com.example.a_zpharmacy.databinding.ActivityLoginBinding

class Drugs_Section : AppCompatActivity() {
    private lateinit var binding: ActivityDrugsSectionBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding= ActivityDrugsSectionBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.Buy.setOnClickListener {

                val buyIntent = Intent(this,Sections::class.java)

                startActivity(buyIntent)
            /* val listOfSelectedItems = ArrayList<String>()
             // true


             // asp
            findViewById<CheckBox>(R.id.Asprin).setOnCheckedChangeListener { buttonView, isChecked ->
                if (isChecked){
                    listOfSelectedItems.add("asprin")
                }else{
                    listOfSelectedItems.remove("asprin")
                }*/
            }



         }
}