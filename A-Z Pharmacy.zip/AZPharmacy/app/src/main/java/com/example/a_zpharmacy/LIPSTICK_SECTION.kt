package com.example.a_zpharmacy

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.a_zpharmacy.databinding.ActivityLipstickSectionBinding

class LipstickSection : AppCompatActivity() {
    private lateinit var binding: ActivityLipstickSectionBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLipstickSectionBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.Buy4.setOnClickListener {
            val buy4Intent = Intent(this, Sections::class.java)
            startActivity(buy4Intent)
        }
    }
}