package com.example.a_zpharmacy

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.a_zpharmacy.databinding.ActivityInjectionsSectionBinding
class InjectionsSection : AppCompatActivity() {
    private lateinit var binding: ActivityInjectionsSectionBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityInjectionsSectionBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.Buy3.setOnClickListener {
            val buy3Intent = Intent(this, Sections::class.java)
            startActivity(buy3Intent)
        }
    }
}