package com.example.a_zpharmacy

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.a_zpharmacy.databinding.ActivityOilsSectionBinding

class OilsSection : AppCompatActivity() {
    private lateinit var binding: ActivityOilsSectionBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityOilsSectionBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.Buy5.setOnClickListener {
            val buy5Intent = Intent(this, Sections::class.java)
            startActivity(buy5Intent)
        }
    }
}