package com.example.a_zpharmacy

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.a_zpharmacy.databinding.ActivityMakeUpSectionBinding

class MakeUp_Section : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_make_up_section)
    }
}